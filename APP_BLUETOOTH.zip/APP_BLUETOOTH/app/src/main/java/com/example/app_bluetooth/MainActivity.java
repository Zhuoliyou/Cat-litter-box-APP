package com.example.app_bluetooth;


import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ScrollView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_BLUETOOTH_PERMISSIONS = 2;
    private static final UUID BT_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;
    private InputStream inputStream;
    private Thread bluetoothThread;
    private Handler handler;

    private Button btnAutoMode, btnManualMode, btnClean, btnConnect, btnClearHistory;
    private TextView tvWeight, tvTime, tvStatus, tvHistoryTitle, tvWeightHistory;
    private ScrollView svHistory;
    private boolean isManualMode = false;
    private boolean isConnected = false;

    // 重量历史记录
    private List<WeightRecord> weightHistory;
    private static final int MAX_HISTORY_SIZE = 50; // 最多保存50条记录

    // 内部类用于存储重量记录
    private static class WeightRecord {
        String weight;
        String timestamp;
        String mode; // 新增模式字段

        WeightRecord(String weight, String timestamp, String mode) {
            this.weight = weight;
            this.timestamp = timestamp;
            this.mode = mode;
        }

        @Override
        public String toString() {
            return timestamp + " - " + weight + " kg [" + mode + "]";
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initBluetooth();
        setupClickListeners();

        handler = new Handler(Looper.getMainLooper());

        // 初始化重量历史记录列表
        weightHistory = new ArrayList<>();
    }

    private void initViews() {
        btnAutoMode = findViewById(R.id.btnAutoMode);
        btnManualMode = findViewById(R.id.btnManualMode);
        btnClean = findViewById(R.id.btnClean);
        btnConnect = findViewById(R.id.btnConnect);
        btnClearHistory = findViewById(R.id.btnClearHistory);
        tvWeight = findViewById(R.id.tvWeight);
        tvTime = findViewById(R.id.tvTime);
        tvStatus = findViewById(R.id.tvStatus);
        tvHistoryTitle = findViewById(R.id.tvHistoryTitle);
        tvWeightHistory = findViewById(R.id.tvWeightHistory);
        svHistory = findViewById(R.id.svHistory);

        // 初始状态下隐藏清理按钮
        btnClean.setVisibility(Button.GONE);
    }

    private void initBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "设备不支持蓝牙", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        checkBluetoothPermissions();
    }

    private void checkBluetoothPermissions() {
        String[] permissions;

        // Android 12+ 需要新的蓝牙权限
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            permissions = new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        } else {
            permissions = new String[]{
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        }

        boolean needsPermission = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                needsPermission = true;
                break;
            }
        }

        if (needsPermission) {
            ActivityCompat.requestPermissions(this, permissions, REQUEST_BLUETOOTH_PERMISSIONS);
        }
    }

    private boolean hasBluetoothPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_BLUETOOTH_PERMISSIONS) {
            boolean allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
                Toast.makeText(this, "权限已授予，现在可以连接蓝牙设备", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要蓝牙权限才能正常使用应用", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setupClickListeners() {
        btnConnect.setOnClickListener(v -> connectToESP32());

        btnAutoMode.setOnClickListener(v -> {
            if (isConnected) {
                sendBluetoothMessage("0xF2");
                isManualMode = false;
                btnClean.setVisibility(Button.GONE);
                tvStatus.setText("当前模式: 自动");
            } else {
                Toast.makeText(this, "请先连接ESP32", Toast.LENGTH_SHORT).show();
            }
        });

        btnManualMode.setOnClickListener(v -> {
            if (isConnected) {
                isManualMode = true;
                btnClean.setVisibility(Button.VISIBLE);
                tvStatus.setText("当前模式: 手动");
            } else {
                Toast.makeText(this, "请先连接ESP32", Toast.LENGTH_SHORT).show();
            }
        });

        btnClean.setOnClickListener(v -> {
            if (isConnected && isManualMode) {
                sendBluetoothMessage("0xF1");
                Toast.makeText(this, "发送清理命令", Toast.LENGTH_SHORT).show();
            }
        });

        btnClearHistory.setOnClickListener(v -> {
            weightHistory.clear();
            updateHistoryDisplay();
            Toast.makeText(this, "历史记录已清空", Toast.LENGTH_SHORT).show();
        });
    }

    private void connectToESP32() {
        // 检查蓝牙权限
        if (!hasBluetoothPermissions()) {
            Toast.makeText(this, "需要蓝牙权限才能连接设备", Toast.LENGTH_SHORT).show();
            checkBluetoothPermissions();
            return;
        }

        try {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                return;
            }

            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            BluetoothDevice esp32Device = null;

            for (BluetoothDevice device : pairedDevices) {
                if (device.getName() != null && device.getName().equals("ESP32_Scale")) {
                    esp32Device = device;
                    break;
                }
            }

            if (esp32Device == null) {
                Toast.makeText(this, "未找到ESP32_Scale设备，请先配对", Toast.LENGTH_SHORT).show();
                return;
            }

            bluetoothSocket = esp32Device.createRfcommSocketToServiceRecord(BT_UUID);
            bluetoothSocket.connect();

            outputStream = bluetoothSocket.getOutputStream();
            inputStream = bluetoothSocket.getInputStream();

            isConnected = true;
            btnConnect.setText("已连接");
            btnConnect.setEnabled(false);

            // 开始监听数据
            startBluetoothDataListener();

            Toast.makeText(this, "连接成功", Toast.LENGTH_SHORT).show();

        } catch (SecurityException e) {
            Toast.makeText(this, "蓝牙权限被拒绝: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "连接失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            isConnected = false;
        }
    }

    private void sendBluetoothMessage(String message) {
        if (outputStream != null) {
            try {
                outputStream.write(message.getBytes());
                outputStream.flush();
            } catch (IOException e) {
                Toast.makeText(this, "发送失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startBluetoothDataListener() {
        bluetoothThread = new Thread(() -> {
            byte[] buffer = new byte[1024];
            int bytes;

            while (isConnected) {
                try {
                    bytes = inputStream.read(buffer);
                    String receivedData = new String(buffer, 0, bytes).trim();

                    handler.post(() -> processReceivedData(receivedData));

                } catch (IOException e) {
                    if (isConnected) {
                        handler.post(() -> {
                            Toast.makeText(MainActivity.this, "连接断开", Toast.LENGTH_SHORT).show();
                            resetConnection();
                        });
                    }
                    break;
                }
            }
        });
        bluetoothThread.start();
    }

    private void processReceivedData(String data) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentTime = sdf.format(new Date());

        if (data.startsWith("WEIGHT:") && data.contains("|0xF3")) {
            // 解析格式: WEIGHT:重量值|0xF3
            String[] parts = data.split("\\|");
            if (parts.length >= 2 && parts[1].trim().equals("0xF3")) {
                String weightStr = parts[0].substring(7); // 去掉"WEIGHT:"前缀

                // 更新当前重量显示
                tvWeight.setText("重量: " + weightStr + " kg");
                tvTime.setText("时间: " + currentTime);

                // 添加到历史记录（包含当前模式）
                addWeightToHistory(weightStr, currentTime);
            }
        } else if (data.equals("0xF3")) {
            // 兼容原来单独发送0xF3的情况
            tvTime.setText("时间: " + currentTime);
        } else if (data.startsWith("WEIGHT:")) {
            // 兼容原来单独发送重量的情况
            String weightStr = data.substring(7); // 去掉"WEIGHT:"前缀
            tvWeight.setText("重量: " + weightStr + " kg");

            // 添加到历史记录（包含当前模式）
            addWeightToHistory(weightStr, currentTime);
        }
    }

    private void addWeightToHistory(String weight, String timestamp) {
        // 获取当前模式字符串
        String currentMode = isManualMode ? "手动" : "自动";

        // 创建新的重量记录，包含模式信息
        WeightRecord record = new WeightRecord(weight, timestamp, currentMode);

        // 添加到列表开头（最新的在最上面）
        weightHistory.add(0, record);

        // 如果超过最大记录数，删除最旧的记录
        if (weightHistory.size() > MAX_HISTORY_SIZE) {
            weightHistory.remove(weightHistory.size() - 1);
        }

        // 更新历史记录显示
        updateHistoryDisplay();
    }

    private void updateHistoryDisplay() {
        StringBuilder historyText = new StringBuilder();

        if (weightHistory.isEmpty()) {
            historyText.append("暂无历史记录");
        } else {
            for (int i = 0; i < weightHistory.size(); i++) {
                WeightRecord record = weightHistory.get(i);
                historyText.append(String.format("%d. %s\n", i + 1, record.toString()));
            }
        }

        tvWeightHistory.setText(historyText.toString());

        // 滚动到顶部显示最新记录
        svHistory.post(() -> svHistory.fullScroll(ScrollView.FOCUS_UP));
    }

    private void resetConnection() {
        isConnected = false;
        btnConnect.setText("连接ESP32");
        btnConnect.setEnabled(true);

        try {
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            // 处理权限相关的安全异常
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "蓝牙已启用", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要启用蓝牙才能使用应用", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        resetConnection();
        if (bluetoothThread != null) {
            bluetoothThread.interrupt();
        }
    }
}